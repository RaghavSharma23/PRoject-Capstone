import Image from "next/image";
import ImageSection from "./sections/imageSection";

export default function Home() {
  return (
    <main>
      <section className="relative z-10 flex justify-center items-center flex-col max-w-7xl mx-auto sm:px-16 px-6">
        <ImageSection />
      </section>
    </main>
  );
}
