"use client";
import { useState } from "react";
import { CheckCircle2, Trash, UploadCloud } from "lucide-react";
import { Button } from "@/components/ui/button";
import Image from "next/image";

const ImageSection = () => {
  const [carImage, setCarImage] = useState<any>(null);
  const [displayedImage, setDisplayedImage] = useState<any>(null);

  const handelImageInput = (e: any) => {
    const file = e.target.files[0];
    setCarImage(file);
    const reader = new FileReader();
    reader.onload = () => {
      if (reader.readyState === 2) {
        setDisplayedImage(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handelImageSubmit = async (e: any) => {
    e.preventDefault();
    if (carImage) {
      const formData = new FormData();
      formData.append("image", carImage);

      try {
        const response = await fetch(
          "http://127.0.0.1:5000/detect_number_plate",
          {
            method: "POST",
            body: formData,
          }
        );

        if (!response.ok) {
          throw new Error("Network response was not ok");
        }

        const responseData = await response.json();
        setDisplayedImage(`/assets/${responseData[0].image_code}.jpg`);
        console.log("Image uploaded successfully:", responseData);
      } catch (error) {
        console.error("Error uploading image:", error);
      }
    } else {
      alert("Please select an image");
    }
  };

  return (
    <section className="mt-8 w-full max-w-xl">
      <div className="flex flex-col w-full gap-2">
        {displayedImage && (
          <div className="h-full w-full rounded-lg shadow-md">
            <div className="relative h-full w-full rounded-lg overflow-hidden">
              <div className="z-30 absolute top-2 right-2">
                <Button
                  onClick={() => {
                    setDisplayedImage(null);
                    setCarImage(null);
                  }}
                  type="button"
                  variant="destructive"
                  size="icon"
                >
                  <Trash className="h-4 w-4" />
                </Button>
              </div>
              <Image
                src={displayedImage}
                alt="food"
                className="h-full w-full rounded-lg object-cover"
                width={300}
                height={200}
              />
            </div>
          </div>
        )}
        {displayedImage === null && (
          <form
            className="relative flex flex-col justify-center items-center"
            autoCapitalize="off"
            autoComplete="off"
            noValidate
          >
            <div className="w-full mx-auto">
              <div className="items-center justify-center w-full">
                <label
                  htmlFor="dropzone-file"
                  className="flex items-center gap-2 p-1 w-full h-24 border-2 border-gray-300 border-dashed rounded-lg text-center cursor-pointer bg-gray-50 dark:hover:bg-bray-800 dark:bg-gray-700 hover:bg-gray-100 dark:border-gray-600 dark:hover:border-gray-500 dark:hover:bg-gray-600"
                >
                  {carImage === null && (
                    <div className="flex flex-col items-center justify-center w-full text-center pt-5 pb-6">
                      <UploadCloud className="w-8 h-8 mb-1 text-gray-400" />
                      <p className="mb-2 text-sm text-gray-500 dark:text-gray-400">
                        <span className="font-semibold">Click to upload</span>{" "}
                        or drag and drop
                      </p>
                    </div>
                  )}
                  <input
                    id="dropzone-file"
                    type="file"
                    className="hidden"
                    onChange={handelImageInput}
                    required
                  />
                </label>
              </div>
            </div>
          </form>
        )}
        {displayedImage !== null && (
          <Button
            className="flex gap-3 items-center justify-center"
            onClick={handelImageSubmit}
          >
            Submit
            <CheckCircle2 className="h-4 w-4" />
          </Button>
        )}
      </div>
    </section>
  );
};

export default ImageSection;
